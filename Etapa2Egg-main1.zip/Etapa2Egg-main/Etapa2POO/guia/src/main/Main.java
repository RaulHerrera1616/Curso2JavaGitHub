package main;

import entidad.Persona;

public class Main {
    public static void main(String[] args) {
        Persona persona = new Persona();
        
        System.out.println(persona);
    }
}