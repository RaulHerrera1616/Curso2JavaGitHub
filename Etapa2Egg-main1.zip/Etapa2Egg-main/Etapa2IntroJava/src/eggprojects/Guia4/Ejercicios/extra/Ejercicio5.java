/*5. Crea un programa que pida el nombre al usuario y lo escriba alternando mayúsculas y minúsculas */
package eggprojects.Guia4.Ejercicios.extra;

public class Ejercicio5 {

}
