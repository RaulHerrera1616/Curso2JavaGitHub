/*4. Crea un programa que pida el nombre al usuario y lo escriba al revés (de la última letra a la primera). */
package eggprojects.Guia4.Ejercicios.extra;

public class Ejercicio4 {
    
}
