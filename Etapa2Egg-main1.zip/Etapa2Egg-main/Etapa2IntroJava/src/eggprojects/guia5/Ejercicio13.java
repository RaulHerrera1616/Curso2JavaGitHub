package eggprojects.guia5;

import java.util.Scanner;

/**Crea un vector llamado ‘Equipo’ cuya dimensión sea la cantidad de compañeros de equipo y define su tipo de dato
 * de tal manera que te permita alojar sus nombres más adelante.
 */
public class Ejercicio13 {


}
